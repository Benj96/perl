\begin{minted}{perl}
{
statement;
statement;
...
}
\end{minted}
