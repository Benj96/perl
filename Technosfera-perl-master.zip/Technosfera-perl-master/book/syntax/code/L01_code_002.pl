\begin{minted}{perl}
do { ... } ≠ { ... }

$value = do { ... }

$value = { ... };
\end{minted}
