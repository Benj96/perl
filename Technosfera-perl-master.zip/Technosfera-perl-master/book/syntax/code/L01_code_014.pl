\begin{minted}{perl}
do {
	...;
} while ( EXPR );

do {
	...;
} until ( EXPR );

do {
	...;
} for ( LIST );
\end{minted}
