\begin{minted}{perl}
$int         = 12345;
$pi          = 3.141592;
$pi_readable = 3.14_15_92_65_35_89;
$plank       = .6626E-33;
$hex         = 0xFEFF;
$bom         = 0xef_bb_bf;
$octal       = 0751;
$binary      = 0b10010011;
\end{minted}
