\begin{minted}{perl}
$one    = "string";
$two    = 'quoted';
$wrap   = "wrap
ped";
$join   = "prefix:$one";
$at     = __FILE__ .':'. __LINE__;
\end{minted}
