\begin{minted}{perl}
$q_1    = q/single-'quoted'/;
$qq_2   = qq(double-"quoted"-$two);
\end{minted}
