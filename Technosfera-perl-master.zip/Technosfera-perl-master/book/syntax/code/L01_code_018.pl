\begin{minted}{perl}
$smile  = ":) -> \x{263A}";
\end{minted}
