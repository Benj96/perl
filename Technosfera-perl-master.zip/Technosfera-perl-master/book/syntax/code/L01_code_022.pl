\begin{minted}{perl}
($a,$b)    = (\"one",\"two");
($a,$b)    = \("one","two");
\end{minted}
