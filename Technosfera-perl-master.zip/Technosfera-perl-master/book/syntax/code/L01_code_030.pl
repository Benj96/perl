\begin{minted}{perl}
%hash  = (key => "value");
say %hash; # key, value

%hash  = {key => "value"};
say %hash; # HASH(0x7fbbd90052f0),
\end{minted}
