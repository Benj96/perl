\begin{minted}{perl}
$sub = sub BLOCK;
$sub = sub (PROTO) BLOCK;
\end{minted}
