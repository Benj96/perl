\begin{minted}{perl}
# scalar context
my $var = mysub(1, 2, $var);
say 10 + mysub();
\end{minted}
