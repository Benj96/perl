\begin{minted}{perl}
# list context
@a = mysub();
($x,$y) = mysub();
\end{minted}
