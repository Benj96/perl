\begin{minted}{perl}
#void context
mysub();
\end{minted}
