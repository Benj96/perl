\begin{minted}{perl}
mysub(...);
mysub ...;
\end{minted}
