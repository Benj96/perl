\begin{minted}{perl}
&mysub(  );
\end{minted}
