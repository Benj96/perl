\begin{minted}{perl}
&mysub;     # ≡ &mysub( @_ );
\end{minted}
