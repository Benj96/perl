\begin{minted}{perl}
$sub->(...);
&$sub(...);
&$sub;      # ≡ &$sub( @_ );
\end{minted}
