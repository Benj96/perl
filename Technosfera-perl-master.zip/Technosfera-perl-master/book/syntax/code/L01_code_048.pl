\begin{minted}{perl}
$ # scalar
@ # list
% # list
* # filehandle
& # special codeblock
; # optional separator
\end{minted}
