\begin{minted}{perl}
(
	my @a = (     #12
	1,              # 1
	2,              # 2
	sort(     #11
			3,     #3
			(
				4     #4
					+     #6
				$v     #5
			),
			(
				6      #7
					x      #9
				2      #8
			),
			7      #10
		)    #11
	)    #12
);
\end{minted}
