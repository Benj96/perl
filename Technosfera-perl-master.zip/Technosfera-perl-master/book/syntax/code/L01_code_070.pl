\begin{minted}{perl}
!0     #  1
!1     # ""
!""    #  1
!undef #  1
\end{minted}
