\begin{minted}{perl}
say +( 1 + 2 ) * 3; # 9
say  ( 1 + 2 ) * 3; # 3
\end{minted}
