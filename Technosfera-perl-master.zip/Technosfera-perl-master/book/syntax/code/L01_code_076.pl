\begin{minted}{perl}
say 9*7; # 63
say 9/7; # 1.28571428571429
say 9%7; # 2
\end{minted}
