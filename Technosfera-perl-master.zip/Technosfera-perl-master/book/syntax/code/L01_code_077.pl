\begin{minted}{perl}
say 9x7; # 9999999
say join ",",(9,10)x3; # 9,10,9,10,9,10
\end{minted}
