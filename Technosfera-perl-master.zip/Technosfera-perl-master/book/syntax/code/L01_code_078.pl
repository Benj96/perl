\begin{minted}{perl}
say 1+2;         # 3
say "1"+"2";     # 3
say "1z" + "2z"; # 3
say "a" + "b";   # 0

say 1.2;         # 1.2
say 1 . 2;       # 12
say "1"."2";     # 12
say "a"."b";     # ab
\end{minted}
