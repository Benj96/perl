\begin{minted}{perl}
say "a" > "b";    # "", 0 > 0
say "a" < "b";    # "", 0 < 0

say 100 gt 20;    # "", "100" gt "20"
say "100" > "20"; # 1
\end{minted}
