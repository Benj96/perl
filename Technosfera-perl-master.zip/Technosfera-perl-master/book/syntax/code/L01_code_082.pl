\begin{minted}{perl}
say "No NaN" if "NaN" == "NaN";
\end{minted}
