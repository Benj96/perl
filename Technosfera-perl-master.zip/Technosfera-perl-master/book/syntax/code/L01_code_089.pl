\begin{minted}{perl}
1   L,ret F :
2   L,ret T R,ret F : 1
3   R,ret F : 2
4   R,ret T : 3E0
5   L,ret F :
\end{minted}
