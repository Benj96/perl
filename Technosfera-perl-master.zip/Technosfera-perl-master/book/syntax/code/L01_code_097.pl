\begin{minted}{perl}
say qx{uname -a};

say qx'echo $HOME';
\end{minted}
