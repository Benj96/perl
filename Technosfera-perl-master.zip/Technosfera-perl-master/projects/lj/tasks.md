| src   | dst   | fields                     | student             |
|-------|-------|----------------------------|---------------------|
| –     | fetch | url                        | Горбушин            |
| –     | –     | –                          | Грубов, Мунькин     |
| fetch | info  | HTML                       | Земцов              |
| info  | links | title, description, author | Овсепян             |
| links | imgs  | links                      | Назаренко           |
| imgs  | pic   | image_links                | Шевяков, Мельникова |
| pic   | tags  | collage                    | Сытенских, Борисов  |
| tags  | words | tags                       | Кулагин             |
| words | og    | words                      | Валинуров           |
| og    | view  | og                         | Федорова            | 
